create definer = root@localhost trigger tr_b4_amortizatia_before_delete
    before delete
    on b4_amortizatia
    for each row
BEGIN
  DELETE FROM b4_minfin      
  WHERE 
    id_insert = old.`id`
    AND
    type_table = "Амортизация";  
  
  DELETE FROM b4_nds      
  WHERE 
    id_insert = old.`id`
    AND
    type_table = "Амортизация";            
END;

