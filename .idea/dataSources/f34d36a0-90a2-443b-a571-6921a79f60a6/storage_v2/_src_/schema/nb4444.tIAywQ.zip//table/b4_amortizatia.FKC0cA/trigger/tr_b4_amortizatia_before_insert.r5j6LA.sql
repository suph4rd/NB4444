create definer = root@localhost trigger tr_b4_amortizatia_before_insert
    before insert
    on b4_amortizatia
    for each row
BEGIN
  DECLARE percent float DEFAULT 0.05;
  DECLARE ostatoc_minfin float;
  DECLARE ostatoc_nds float;  

  SET ostatoc_minfin = (SELECT ostatoc_minfin FROM b4_minfin ORDER BY id DESC LIMIT 1) - new.sum_amortizatia;
  SET ostatoc_nds = (SELECT ostatoc_nds FROM b4_nds ORDER BY id DESC LIMIT 1) + new.sum_amortizatia * percent;     


  IF new.sum_amortizatia > 0 
    THEN

     INSERT INTO b4_nds(
      date_nds, 
      ostatoc_nds, 
      sum_nds, 
      describe_nds,
      type_table,
      id_insert
                        )
     VALUES (
      new.date_amortizatia,
      ostatoc_nds,
      new.sum_amortizatia * percent,
      new.describe_amortizatia,
      "Амортизация",
      new.`id`
        ); 
  END IF;  
  
  INSERT INTO b4_minfin(
      date_minfin, 
      ostatoc_minfin, 
      sum_minfin, 
      describe_minfin,
      type_table,
      id_insert
                        )
    VALUES (
      new.date_amortizatia,
      ostatoc_minfin,
      new.sum_amortizatia,
      new.describe_amortizatia,
      "Амортизация",
      new.`id`
        );

  SET new.sum_amortizatia = new.sum_amortizatia * (pecrent + 1);
  SET new.ostatoc_amortizatia = (SELECT ostatoc_amortizatia FROM b4_amortizatia ORDER BY id DESC LIMIT 1) - new.sum_amortizatia;

END;

