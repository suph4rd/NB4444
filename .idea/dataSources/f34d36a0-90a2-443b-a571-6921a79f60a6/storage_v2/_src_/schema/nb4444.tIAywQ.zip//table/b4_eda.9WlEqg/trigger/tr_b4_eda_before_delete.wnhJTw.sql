create definer = root@localhost trigger tr_b4_eda_before_delete
    before delete
    on b4_eda
    for each row
BEGIN
  DELETE FROM b4_minfin      
  WHERE 
    id_insert = old.`id`
    AND
    type_table = "Еда";  
  
  DELETE FROM b4_nds      
  WHERE 
    id_insert = old.`id`
    AND
    type_table = "Еда";             
END;

