create definer = root@localhost trigger tr_b4_eda_before_insert
    before insert
    on b4_eda
    for each row
BEGIN
  DECLARE percent float DEFAULT 0.1;
  DECLARE ostatoc_minfin float;
  DECLARE ostatoc_nds float;  

  SET ostatoc_minfin = (SELECT ostatoc_minfin FROM b4_minfin ORDER BY id DESC LIMIT 1) - new.sum_eda;
  SET ostatoc_nds = (SELECT ostatoc_nds FROM b4_nds ORDER BY id DESC LIMIT 1) + new.sum_eda * percent;     
     

  IF new.sum_eda > 0 
    THEN
     
       INSERT INTO b4_nds(
        date_nds, 
        ostatoc_nds, 
        sum_nds, 
        describe_nds,
        type_table,
        id_insert      
                          )
       VALUES (
        new.date_eda,
        ostatoc_nds,
        new.sum_eda * percent,
        new.describe_eda,
        "Еда",
        new.`id`     
        ); 

  END IF;  
  
  INSERT INTO b4_minfin(
      date_minfin, 
      ostatoc_minfin, 
      sum_minfin, 
      describe_minfin,
      type_table,
      id_insert
                        )
    VALUES (
      new.date_eda,
      ostatoc_minfin,
      new.sum_eda,
      new.describe_eda,
      "Еда",
      new.`id`
        );
  
  SET new.sum_eda = new.sum_eda * (pecrent + 1);
  SET new.ostatoc_eda = (SELECT ostatoc_eda FROM b4_eda ORDER BY id DESC LIMIT 1) - new.sum_eda;

END;

