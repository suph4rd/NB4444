create definer = root@localhost trigger tr_b4_nds_before_insert
    before insert
    on b4_nds
    for each row
BEGIN
  DECLARE ostatoc_minfin float;
  SET ostatoc_minfin = (SELECT ostatoc_minfin FROM b4_minfin ORDER BY id DESC LIMIT 1) - new.sum_nds;
  
  INSERT INTO b4_minfin(
      date_minfin, 
      ostatoc_minfin, 
      sum_minfin, 
      describe_minfin,
      type_table,
      id_insert
                        )
    VALUES (
      new.date_nds,
      ostatoc_minfin,
      new.sum_nds,
      new.describe_nds,
      "НДС",
      new.`id`
        );
  
  SET new.ostatoc_nds = (SELECT ostatoc_nds FROM b4_nds ORDER BY id DESC LIMIT 1) + new.sum_nds;
END;

