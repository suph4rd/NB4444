create definer = root@localhost trigger tr_b4_prochee_before_delete
    before delete
    on b4_prochee
    for each row
BEGIN
  DELETE FROM b4_minfin      
  WHERE 
    id_insert = old.`id`
  AND
    type_table = "Прочее";              
END;

