create definer = root@localhost trigger tr_b4_prochee_before_insert
    before insert
    on b4_prochee
    for each row
BEGIN
DECLARE ostatoc_minfin float;
SET ostatoc_minfin = (SELECT ostatoc_minfin FROM b4_minfin ORDER BY id DESC LIMIT 1) - new.sum_prochee;
  
  INSERT INTO b4_minfin(
      date_minfin, 
      ostatoc_minfin, 
      sum_minfin, 
      describe_minfin,
      type_table,
      id_insert
                        )
    VALUES (
      new.date_prochee,
      ostatoc_minfin,
      new.sum_prochee,
      new.describe_prochee,
      "Прочее",
      new.`id`
        );

  SET new.ostatoc_prochee = (SELECT ostatoc_prochee FROM b4_prochee ORDER BY id DESC LIMIT 1) - new.sum_prochee;
END;

