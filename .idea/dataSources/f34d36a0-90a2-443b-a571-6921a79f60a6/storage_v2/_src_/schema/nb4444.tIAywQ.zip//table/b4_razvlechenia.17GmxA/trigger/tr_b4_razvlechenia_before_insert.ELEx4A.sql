create definer = root@localhost trigger tr_b4_razvlechenia_before_insert
    before insert
    on b4_razvlechenia
    for each row
BEGIN
  DECLARE percent float DEFAULT 0.3;
  DECLARE ostatoc_minfin float;
  DECLARE ostatoc_nds float;  

  SET ostatoc_minfin = (SELECT ostatoc_minfin FROM b4_minfin ORDER BY id DESC LIMIT 1) - new.sum_razvlechenia;
  SET ostatoc_nds = (SELECT ostatoc_nds FROM b4_nds ORDER BY id DESC LIMIT 1) + new.sum_razvlechenia * percent;     

  IF new.sum_razvlechenia > 0 
    THEN
     
     INSERT INTO b4_nds(
      date_nds, 
      ostatoc_nds, 
      sum_nds, 
      describe_nds,
      type_table,
      id_insert      
                        )
     VALUES (
      new.date_razvlechenia,
      ostatoc_nds,
      new.sum_razvlechenia * percen,
      new.describe_razvlechenia,
      "Развлечения",
      new.`id`
        ); 
  END IF;  
  
  INSERT INTO b4_minfin(
      date_minfin, 
      ostatoc_minfin, 
      sum_minfin, 
      describe_minfin,
      type_table,
      id_insert
                        )
    VALUES (
      new.date_razvlechenia,
      ostatoc_razvlechenia,
      new.sum_razvlechenia,
      new.describe_razvlechenia,
      "Развлечения",
      new.`id`
        );

  SET new.sum_razvlechenia = new.sum_razvlechenia * (pecrent + 1);
  SET new.ostatoc_razvlechenia = (SELECT ostatoc_razvlechenia FROM b4_razvlechenia ORDER BY id DESC LIMIT 1) - new.sum_razvlechenia;

END;

