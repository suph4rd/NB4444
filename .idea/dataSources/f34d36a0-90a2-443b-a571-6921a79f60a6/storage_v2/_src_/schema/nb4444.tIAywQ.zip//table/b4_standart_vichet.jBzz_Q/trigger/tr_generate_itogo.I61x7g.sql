create definer = root@localhost trigger tr_generate_itogo
    before insert
    on b4_standart_vichet
    for each row
BEGIN
  SET new.itogo = new.hata 
                + new.proezd 
                + new.mobila
                + new.eda;
END;

