create definer = root@localhost trigger tr_b4_transport_before_insert
    before insert
    on b4_transport
    for each row
BEGIN
 DECLARE ostatoc_minfin float;
 SET ostatoc_minfin = (SELECT ostatoc_minfin FROM b4_minfin ORDER BY id DESC LIMIT 1) - new.sum_transport;

  INSERT INTO b4_minfin(
      date_minfin, 
      ostatoc_minfin, 
      sum_minfin, 
      describe_minfin,
      type_table,
      id_insert
                        )
    VALUES (
      new.date_transport,
      ostatoc_minfin,
      new.sum_transport,
      new.describe_transport,
      "Транспорт",
      new.`id`
        );

  SET new.ostatoc_transport = (SELECT ostatoc_transport FROM b4_transport ORDER BY id DESC LIMIT 1) - new.sum_transport;
END;

